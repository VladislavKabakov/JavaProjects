package com.springbootex.SpringBoot.project.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

//@Component Whenever the context starts, this component will be added to a container
//@Controller
@RestController // Controller + response body
public class HelloController {
    // @RequestMapping(value = "/", method = RequestMethod.GET)

    @Value("${welcome.message}")
    private String welcomeMessage;
    @GetMapping("/")
    public String helloWorlds() {
        return welcomeMessage;
    }
}
