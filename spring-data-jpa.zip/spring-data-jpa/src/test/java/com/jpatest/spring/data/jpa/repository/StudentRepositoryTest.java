package com.jpatest.spring.data.jpa.repository;

import com.jpatest.spring.data.jpa.entity.Guardian;
import com.jpatest.spring.data.jpa.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
// @DataJpaTest - helps to test repository layer
class StudentRepositoryTest {
    @Autowired
    private StudentRepository studentRepository;

    // To add data to a db
    @Test
    public void saveStudent() {
        Student student = Student.builder()
                .emailId("vlad@gmail.com")
                .firstName("Vladislav")
                .lastName("vvv")
                //.guardianName("lll")
                //.guardianEmail("lll@gmail.com")
                //.guardianMobile("1234567")
                .build();

        studentRepository.save(student);

    }
    @Test
    public void saveStudentWithGuardian() {
        Guardian guardian = Guardian.builder()
                .email("lll@gmail.com")
                .name("lll")
                .mobile("1234567")
                .build();

        Student student = Student.builder()
                .firstName("mee")
                .emailId("mee@gmail.com")
                .lastName("lee")
                .guardian(guardian)
                .build();

        studentRepository.save(student);
    }

    //To display students' info
    @Test
    public void printAllStudents() {
        List<Student> studentsList = studentRepository.findAll();
        System.out.println("studentsList = " + studentsList);
    }
    @Test
    public void printStudentByFirstName() {

        List<Student> students = studentRepository.findByFirstName("Vladislav");
        System.out.println("students  = " + students);
    }

    @Test
    public void printStudentByFirstNameContaining() {

        List<Student> students = studentRepository.findByFirstName("vl");
        System.out.println("students  = " + students);
    }

    @Test
    public void printStudentBasedOnGuardianName() {
        List<Student> students = studentRepository.findByGuardianName("lll");
        System.out.println("students  = " + students);
    }
    @Test
    public void printStudentByEmailAddress() {
        Student student = studentRepository.getStudentByEmailAddress("vlad@gmail.com");
        System.out.println("student = " + student);
    }
    @Test
    public void printStudentFirstNameByEmailAddress() {
        String firstName = studentRepository.getStudentFirstNameByEmailAddress("vlad@gmail.com");
        System.out.println("firstName = " + firstName);
    }

    @Test
    public void printStudentByEmailAddressNative() {
        Student student = studentRepository.getStudentByEmailAddress("vlad@gmail.com");
        System.out.println("firstName = " + student);
    }

}