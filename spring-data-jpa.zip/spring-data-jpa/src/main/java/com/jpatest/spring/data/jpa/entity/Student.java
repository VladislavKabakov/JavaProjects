package com.jpatest.spring.data.jpa.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity // To represent this class to a db (to mark it as an entity)
@Data // To generate getters & setters
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(
        name = "tbl_student",
        uniqueConstraints = @UniqueConstraint(
                name = "emailid_unique",
                columnNames = "email_address"
        )
) // To add this entity to a db -> New table will be created + Constraints
public class Student {
    @Id // To define a field as a primary key

    // To create a sequence
    @SequenceGenerator (
        name = "student_sequence",
        sequenceName = "student_sequence",
        allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "student_sequence"
    )
    private Long StudentId;
    private String firstName;
    private String lastName;
    @Column(
            name = "email_address",
            nullable = false
    ) // To give a particular name to a column in a db + NOT NULL
    private String emailId;
    @Embedded
    private Guardian guardian;
}
