package com.jpatest.spring.data.jpa.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString(exclude = "course")
public class CourseMaterial {
    @Id
    @SequenceGenerator(
            name = "course_material_sequence",
            sequenceName = "course_material_sequence",
            allocationSize = 1
    )
    @GeneratedValue (
            strategy = GenerationType.SEQUENCE,
            generator = "course_material_sequence"
    )
    private Long courseMaterialId;
    private String url;

    // Creating foreign key
    /*
    cascadeType.ALL означает, что необходимо выполнять каскадно все операции. В данном случае -
    создать запись в таблице Course, чтобы затем создать запись в таблице CourseMaterial

    fetchType: eager / lazy
    */

    @OneToOne(
            cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, // fetchType: eager / lazy
            optional = false // Not to allow adding course without course material
    )
    @JoinColumn(
            name = "course_id",
            referencedColumnName = "courseId"
    )
    private Course course;

}
