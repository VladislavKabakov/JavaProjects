package com.employeeapp.address.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
