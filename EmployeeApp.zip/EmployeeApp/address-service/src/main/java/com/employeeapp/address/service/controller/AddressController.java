package com.employeeapp.address.service.controller;

import com.employeeapp.address.service.response.AddressResponse;
import com.employeeapp.address.service.service.AddressService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AddressController {

    @Autowired
    private AddressService addressService;

    @GetMapping("/address/{employeeId}")
    public ResponseEntity<AddressResponse> getAddressByEmployeeId(@PathVariable("employeeId") int employeeId) {

        AddressResponse addressResponse = addressService.findAddressByEmployeeId(employeeId);

        return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
    }

    @GetMapping("/address")
    public ResponseEntity<List<AddressResponse>> getAllAddress() {
        List<AddressResponse> addressResponse = addressService.getAllAddress();
        return ResponseEntity.status(HttpStatus.OK).body(addressResponse);
    }
}
