package com.employeeapp.address.service.repository;

import com.employeeapp.address.service.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AddressRepo extends JpaRepository<Address, Integer> {
    @Query(nativeQuery = true, value = "SELECT * FROM address a JOIN employee e ON e.id = a.employee_id WHERE a.employee_id =: employeeId")
    Address findAddressByEmployeeId(@Param("employeeId") int employeeId);
}
