package com.employeeapp.service.openfeignclient;

import com.employeeapp.service.response.AddressResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "ADDRESS-SERVICE", path = "/address-app/api/")
public interface AddressClient { // Creates a proxy in the runtime

    @GetMapping("/address/{employeeId}")
    ResponseEntity<AddressResponse> getAddressByEmployeeId(@PathVariable("employeeId") int employeeId);

    @GetMapping("/address")
    public ResponseEntity<List<AddressResponse>> getAllAddress();
}
