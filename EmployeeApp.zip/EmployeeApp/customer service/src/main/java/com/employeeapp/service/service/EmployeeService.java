package com.employeeapp.service.service;

import com.employeeapp.service.entity.Employee;
import com.employeeapp.service.openfeignclient.AddressClient;
import com.employeeapp.service.repository.EmployeeRepo;
import com.employeeapp.service.response.AddressResponse;
import com.employeeapp.service.response.EmployeeResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Arrays;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private WebClient webClient;
    @Autowired
    private DiscoveryClient discoveryClient;

    private AddressClient addressClient;

//    @Autowired
//    private LoadBalancerClient loadBalancerClient;

    public List<EmployeeResponse> getAllEmployees() {

        List<Employee> employeeList = employeeRepo.findAll();
        List<EmployeeResponse> employeeResponse = Arrays.asList(modelMapper.map(employeeList, EmployeeResponse.class));

        ResponseEntity<List<AddressResponse>> allAddress = addressClient.getAllAddress();
        List<AddressResponse> addressResponse = allAddress.getBody();
        employeeResponse.forEach(employee -> {
            for (AddressResponse addrResponse : addressResponse) {
                if (addrResponse.getEmployeeId() == employee.getId()) {
                    employee.setAddressResponse(addrResponse);
                }
            }
        });
        return employeeResponse;
    }

    public EmployeeResponse getEmployeeById(int id) {

        // employee -> employeeResponse
        Employee employee = employeeRepo.findById(id).get();
        EmployeeResponse employeeResponse = modelMapper.map(employee, EmployeeResponse.class);

        ResponseEntity<AddressResponse> addressResponseEntity = addressClient.getAddressByEmployeeId(id);
        AddressResponse addressResponse = addressResponseEntity.getBody();

        // AddressResponse addressResponse = callingAddressServiceUsingWebClient(id);
        // AddressResponse addressResponse = callingAddressServiceUsingRestTemplate(id);
        employeeResponse.setAddressResponse(addressResponse);

        return employeeResponse;
    }

    private AddressResponse callingAddressServiceUsingRestTemplate(int id) {

        // Getting the details about the IP and PortNumber
//       List<ServiceInstance> instances = discoveryClient.getInstances("address-service");
//       ServiceInstance serviceInstance = instances.get(0);
//       String uri = serviceInstance.getUri().toString();
//
//        ServiceInstance serviceInstance = loadBalancerClient.choose("address-service");
//        String uri = serviceInstance.getUri().toString();
//        String contextRoot = serviceInstance.getMetadata().get("configPath");

        // We can also give the name of the particular service in the url path (ex.ADDRESS-SERVICE)
        return restTemplate.getForObject("http://ADDRESS-SERVICE/address-app/apiaddress/{id}", AddressResponse.class, id);
    }

    private AddressResponse callingAddressServiceUsingWebClient(int id) {
        return webClient
                .get()
                .uri("/address/" + id)
                .retrieve()
                .bodyToMono(AddressResponse.class)
                .block();
    }

}
